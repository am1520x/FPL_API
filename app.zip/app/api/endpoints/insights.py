# app/api/endpoints/insights.py
from fastapi import APIRouter, HTTPException, Depends
from typing import List, Any, Dict
from sqlalchemy.orm import Session
from app.services.fpl_entry_service import FPLEntryService
from app.services.insights_service import InsightsService, Insight
from app.core.database import get_db

router = APIRouter(prefix="/entry", tags=["insights"])

@router.get("/{entry_id}/insights", response_model=List[Dict[str, Any]])
def get_insights(entry_id: int, gw: int = None, db: Session = Depends(get_db)):
    try:
        fpl_service = FPLEntryService(db)
        # 1) fetch picks for current GW (or provided gw)
        if gw is None:
            gw = fpl_service.get_current_event()
        picks_json = fpl_service.fetch_entry_picks(entry_id, event_id=gw)
        # You would then convert picks_json → DataFrame enriched_df
        # 2) compute future_df for next horizon
        # 3) call InsightsService.generate_insights(...)
        insights_service = InsightsService(fpl_service, bootstrap_cache=None)  # implement bootstrap_cache as needed
        insights = insights_service.generate_insights(
            enriched_df=enriched_df,
            future_df=future_df,
            gw=gw,
            get_element_summaries_fn=fpl_service.fetch_element_summaries  # you’d implement this
        )
        # convert List[Insight] → JSON-serializable (dicts)
        result = [{"title": i.title, "items": i.items} for i in insights]
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
